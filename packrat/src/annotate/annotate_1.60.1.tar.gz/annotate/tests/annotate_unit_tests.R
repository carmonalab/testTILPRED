BiocGenerics:::testPackage("annotate")
